package fsc;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.regex.Pattern;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class LoginFrame {	
	
	String ipPort;
	
	public LoginFrame(){
		
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
				
		final JFrame login = new JFrame("Start MqttClient - tcp");
		login.setResizable(false);
		login.setSize(400, 100);
		login.setLocation(dim.width/2-login.getSize().width/2, dim.height/2-login.getSize().height/2);
		login.setLayout(new FlowLayout());
		
		JButton ok = new JButton("Accedi");
		JButton esci = new JButton("Esci");
		
		JLabel ipLabel = new JLabel("Indirizzo IP: ");
		JLabel portaLabel = new JLabel("Porta: ");
		
		final JTextField ipTextField = new JTextField(15);
		final JTextField portaTextField = new JTextField(5);
		
		
		JPanel jPanelInput = new JPanel();
		
		jPanelInput.add(ipLabel);
		jPanelInput.add(ipTextField);
		
		jPanelInput.add(portaLabel);
		jPanelInput.add(portaTextField);
		
		JPanel jPanelButton = new JPanel();
		
		jPanelButton.add(ok);
		jPanelButton.add(esci);
				
		login.getContentPane().add(jPanelInput, BorderLayout.CENTER);
		login.getContentPane().add(jPanelButton, BorderLayout.PAGE_END);
		
		login.setVisible(true);
		
		
		ok.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				String ip = ipTextField.getText();
				String porta = portaTextField.getText();
				
				ipPort = "tcp://"+ip+":"+porta;
				//System.out.println(ipPort);
				
				if(validate(ip) && validatePort(porta)){
					@SuppressWarnings("unused")
					DynamicLineAndTimeSeriesChart demo = new DynamicLineAndTimeSeriesChart(ipPort);
				}
				else {
					JOptionPane.showMessageDialog(login,"Hai inserito un ip e/o porta non valida.","Errore", JOptionPane.ERROR_MESSAGE);
				}
				
			}

		});
		
		esci.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if (JOptionPane.showConfirmDialog(login, "Sei sicuro di voler chiudere ?", "Conferma uscita.", JOptionPane.OK_OPTION, 0, new ImageIcon("")) != 0) {
	                return;
	            }
	            System.exit(-1);
				
			}
		});
	}	
	
	private static boolean validatePort(final String porta) {
		return (porta.matches("[0-9]+") && porta.length() <= 5 && (Integer.parseInt(porta) < 65536));
	}
	
	private static final Pattern PATTERN = Pattern.compile(
	        "^(([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.){3}([01]?\\d\\d?|2[0-4]\\d|25[0-5])$");

	public static boolean validate(final String ip) {
	    return PATTERN.matcher(ip).matches();
	}
}
