package fsc;

import javax.swing.Timer;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.time.Millisecond;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.jfree.data.xy.XYDataset;

public class DynamicLineAndTimeSeriesChart implements ActionListener, MqttCallback {

    /** The time series data. */
    private TimeSeries seriesAccX;
    private TimeSeries seriesAccY;
    private TimeSeries seriesAccZ;
    
    private TimeSeries seriesGyX;
    private TimeSeries seriesGyY;
    private TimeSeries seriesGyZ;
    
    /** Timer to refresh graph after every 1/4th of a second */
    private Timer timer = new Timer(250, this);

	MqttClient client;
		
	double xAcc = 0;
	double yAcc = 0;
	double zAcc = 0;
	
	double xGy = 0;
	double yGy = 0;
	double zGy = 0;

	String msgAcc;
	String msgGy;
	
	final JTextArea consoleAcc;
	final JTextArea consoleGy;
	
	
	/**
     * Constructs a new dynamic chart application.
     *
     * @param title  the frame title.
     * @throws MqttException 
     */
    @SuppressWarnings("deprecation")
	public DynamicLineAndTimeSeriesChart(String ip) {
    	
        seriesAccX = new TimeSeries("X Acc", Millisecond.class);
        seriesAccY = new TimeSeries("Y Acc", Millisecond.class);
        seriesAccZ = new TimeSeries("Z Acc", Millisecond.class);
        
        seriesGyX = new TimeSeries("X Gy", Millisecond.class);
        seriesGyY = new TimeSeries("Y Gy", Millisecond.class);
        seriesGyZ = new TimeSeries("Z Gy", Millisecond.class);
         
        
        final TimeSeriesCollection datasetAccX = new TimeSeriesCollection(seriesAccX);
        final TimeSeriesCollection datasetAccY = new TimeSeriesCollection(seriesAccY);
        final TimeSeriesCollection datasetAccZ = new TimeSeriesCollection(seriesAccZ);
        
        final TimeSeriesCollection datasetGyX = new TimeSeriesCollection(seriesGyX);
        final TimeSeriesCollection datasetGyY = new TimeSeriesCollection(seriesGyY);
        final TimeSeriesCollection datasetGyZ = new TimeSeriesCollection(seriesGyZ);
        
        final JFreeChart chartAccX = createChart(datasetAccX,"Accellerometro X", "X");
        final JFreeChart chartAccY = createChart(datasetAccY,"Accellerometro Y", "Y");
        final JFreeChart chartAccZ = createChart(datasetAccZ,"Accellerometro Z", "Z");
        
        final JFreeChart chartGyX = createChart(datasetGyX,"Giroscopio X", "X");
        final JFreeChart chartGyY = createChart(datasetGyY,"Giroscopio Y", "Y");
        final JFreeChart chartGyZ = createChart(datasetGyZ,"Giroscopio Z", "Z");
        
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
                
        timer.setInitialDelay(1000);

        //Sets background color of chart
        chartAccX.setBackgroundPaint(Color.LIGHT_GRAY);
        chartAccY.setBackgroundPaint(Color.LIGHT_GRAY);
        chartAccZ.setBackgroundPaint(Color.LIGHT_GRAY);

        chartGyX.setBackgroundPaint(Color.LIGHT_GRAY);
        chartGyY.setBackgroundPaint(Color.LIGHT_GRAY);
        chartGyZ.setBackgroundPaint(Color.LIGHT_GRAY);

        final JFrame frame = new JFrame("MqttClient");
        
        //Created JPanel to show graph on screen
        final JPanel content = new JPanel();
        final JPanel content1 = new JPanel();
        final JPanel content2 = new JPanel();
        
        final JPanel contentConsole = new JPanel();
        contentConsole.setLayout(new BorderLayout());
        JLabel jLabelAcc = new JLabel("Console Accellerometro");
        consoleAcc = new JTextArea( 22, 20 );
        //consoleAcc.setSize(100, 100);
        consoleAcc.setLineWrap(true);
        consoleAcc.setWrapStyleWord(false);
        JScrollPane scrollPane = new JScrollPane(consoleAcc);
        scrollPane.setVerticalScrollBarPolicy ( ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS );        
        consoleAcc.setEditable(false);
        
        final JPanel contentConsole1 = new JPanel();
        contentConsole1.setLayout(new BorderLayout());
        JLabel jLabelGy = new JLabel("Console Giroscopio");
        consoleGy = new JTextArea(22,20);
        //consoleGy.setSize(100, 100);
        consoleGy.setEditable(false);
        JScrollPane scrollPane1 = new JScrollPane(consoleGy);
        scrollPane1.setVerticalScrollBarPolicy ( ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS );
        
        final JPanel contentAllConsole = new JPanel();
        contentAllConsole.setLayout(new BorderLayout());

        
        
        //Created Chartpanel for chart area
        final ChartPanel panelAccX = new ChartPanel(chartAccX);
        final ChartPanel panelAccY = new ChartPanel(chartAccY);
        final ChartPanel panelAccZ = new ChartPanel(chartAccZ);
        
        final ChartPanel panelGyX = new ChartPanel(chartGyX);
        final ChartPanel panelGyY = new ChartPanel(chartGyY);
        final ChartPanel panelGyZ = new ChartPanel(chartGyZ);
        
        frame.setSize(dim.width - 30, dim.height - 25);
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setResizable(false);
        frame.setLayout( new BorderLayout());  

                
        //Added chartpanel to main panel
        content1.add(panelAccX);
        content1.add(panelAccY);
        content1.add(panelAccZ);
        
        content2.add(panelGyX);
        content2.add(panelGyY);
        content2.add(panelGyZ);
        
        content.setLayout(new BorderLayout());
        content.add(content1, BorderLayout.NORTH);
        content.add(content2, BorderLayout.SOUTH);
        
        
        contentConsole.add(jLabelAcc, BorderLayout.NORTH);
        contentConsole.add(scrollPane, BorderLayout.CENTER);
        
        contentConsole1.add(jLabelGy, BorderLayout.NORTH);
        contentConsole1.add(scrollPane1, BorderLayout.CENTER);
        
        contentAllConsole.add(contentConsole, BorderLayout.NORTH);
        contentAllConsole.add(contentConsole1, BorderLayout.SOUTH);
        
        //Sets the size of whole window (JPanel)
        
        panelAccX.setPreferredSize(new java.awt.Dimension(350, 350));
        panelAccY.setPreferredSize(new java.awt.Dimension(350, 350));
        panelAccZ.setPreferredSize(new java.awt.Dimension(350, 350));
        
        panelGyX.setPreferredSize(new java.awt.Dimension(350, 350));
        panelGyY.setPreferredSize(new java.awt.Dimension(350, 350));
        panelGyZ.setPreferredSize(new java.awt.Dimension(350, 350));
        
        //Puts the whole content on a Frame
        //frame.setContentPane(content);
        //frame.setContentPane(contentConsole);
        frame.add(content, BorderLayout.WEST);
        frame.add(contentAllConsole, BorderLayout.EAST);
        
        frame.addWindowListener(new WindowListener() {
			
			@Override
			public void windowOpened(WindowEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void windowIconified(WindowEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void windowDeiconified(WindowEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void windowDeactivated(WindowEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void windowClosing(WindowEvent e) {
				// TODO Auto-generated method stub
				if (JOptionPane.showConfirmDialog(frame, "Sei sicuro di voler chiudere ?", "Conferma uscita.", JOptionPane.OK_OPTION, 0, new ImageIcon("")) != 0) {
	                return;
	            }
	            System.exit(-1);
			}
			
			@Override
			public void windowClosed(WindowEvent e) {
				// TODO Auto-generated method stub
				try {
					client.disconnect();
				} catch (MqttException e1) {
					System.out.println("Non sono riuscito a chiudere la connessione");
					e1.printStackTrace();
				}
				
			}
			
			@Override
			public void windowActivated(WindowEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
        
        frame.setVisible(true);
        
        connectAndSubscribe(ip);
        
        timer.start();
    }
    

    public void connectAndSubscribe(String ip) {
	    try {
	    	
	        client = new MqttClient(ip, "JavaMQTTClient");
	        client.connect();
	        
	        client.setCallback(this);
	        client.subscribe("Acc");
	        client.subscribe("Gy");

	    } catch (MqttException e) {
	        e.printStackTrace();
	    }
	}

    /**
     * Creates a sample chart.
     *
     * @param dataset  the dataset.
     *
     * @return A sample chart.
     */
    private JFreeChart createChart(final XYDataset dataset, String title, String yName) {
        final JFreeChart result = ChartFactory.createTimeSeriesChart(
            title,
            "Time",
            yName,
            dataset,
            true,
            true,
            false
        );

        final XYPlot plot = result.getXYPlot();

        plot.setBackgroundPaint(new Color(0xffffe0));
        plot.setDomainGridlinesVisible(true);
        plot.setDomainGridlinePaint(Color.lightGray);
        plot.setRangeGridlinesVisible(true);
        plot.setRangeGridlinePaint(Color.lightGray);

        ValueAxis xaxis = plot.getDomainAxis();
        xaxis.setAutoRange(true);

        //Domain axis would show data of 60 seconds for a time
        xaxis.setFixedAutoRange(60000.0);  // 60 seconds
        xaxis.setVerticalTickLabels(true);

        //ValueAxis yaxis = plot.getRangeAxis();
        //yaxis.setRange(0.0, 300.0);

        return result;
    }
    /**
     * Generates an random entry for a particular call made by time for every 1/4th of a second.
     *
     * @param e  the action event.
     */

    public void actionPerformed(final ActionEvent e) {
    	// valori da stampare

        seriesAccX.add(new Millisecond(), xAcc);
        seriesAccY.add(new Millisecond(), yAcc);
        seriesAccZ.add(new Millisecond(), zAcc);
        
        seriesGyX.add(new Millisecond(), xGy);
        seriesGyY.add(new Millisecond(), yGy);
        seriesGyZ.add(new Millisecond(), zGy);
        
        consoleAcc.append(msgAcc);
        consoleGy.append(msgGy);
    }
    

    /**
     * Starting point for the dynamic graph application.
     *
     * @param args  ignored.
     */
    /*public static void main(final String[] args) {

    	//final LoginFrame loginFrame = new LoginFrame();
        //final DynamicLineAndTimeSeriesChart demo = new DynamicLineAndTimeSeriesChart();
        
        
                
    }*/

	@Override
	public void connectionLost(Throwable arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deliveryComplete(IMqttDeliveryToken arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void messageArrived(String topic, MqttMessage message) throws Exception {
		
		double x = 0;
		double y = 0;
		double z = 0;
		
		String[] parts = message.toString().split(";");
		
		for(int i=0; i<parts.length; i++){
			String[] temp=parts[i].split("=");
			
			switch (temp[0]) {
			case "X":
				x = Double.parseDouble(temp[1]);
				break;
			case "Y":
				y = Double.parseDouble(temp[1]);
				break;
			case "Z":
				z = Double.parseDouble(temp[1]);
				break;
			default:
				break;
			}			
		}
    	
		if(topic.equals("Acc")){						
			xAcc = x;
			yAcc = y;
			zAcc = z;
			msgAcc = new String(message.toString()+"\n");
		}
		else if(topic.equals("Gy")){
			xGy = x;
			yGy = y;
			zGy = z;
			msgGy = new String(message.toString() + "\n");		
		}
	}
}